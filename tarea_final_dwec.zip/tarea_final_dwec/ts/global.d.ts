

interface ApiResponse {
    info: {
        total: number;
        page: number;
        limit: number;
        next: string | null;
        prev: string | null;
    };
    data: Character[];
}

interface Character {
    _id: string;
    name: string;
    description: string;
    image: string;
    __v: number;
}
