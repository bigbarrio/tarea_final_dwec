$(document).ready(() => {
    let currentPage: number = 1; // Inicia en la página 1
    const limit: number = 10; // Número de personajes por página
    let characterIds: string[] = []; // Especifica explícitamente el tipo como string[]
    let currentDetailIndex: number = 0; // Índice del detalle del personaje actualmente visible

    interface Character {
        _id: string;
        name: string;
        image: string;
        description?: string; // Asumiendo que la descripción puede estar presente
    }

    interface ApiResponse {
        data: Character[];
        info: {
            next: string | null;
            prev: string | null;
        };
    }

    // Función para cargar personajes según la página actual
    function loadCharacters(page: number): void {
        const charactersUrl: string = `https://starwars-databank-server.vercel.app/api/v1/characters?page=${page}&limit=${limit}`;

        $.get(charactersUrl, (response: ApiResponse) => {
            let html: string = "<div>"; // Contenedor para las tarjetas de personajes
            characterIds = response.data.map((character: Character) => character._id); // Actualiza el arreglo de IDs
            response.data.forEach((character: Character) => {
                html += `<div class="character-card" data-id="${character._id}">
                            <img src="${character.image}" alt="${character.name}" class="character-image">
                            <h2 class="character-name">${character.name}</h2>
                         </div>`;
            });
            html += "</div>";
            $('#data').html(html);

            // Asigna el evento de clic a cada tarjeta de personaje
            $('.character-card').click(function() {
                const characterId: string = $(this).data('id');
                const index: number = characterIds.indexOf(characterId);
                if (index !== -1) {
                    currentDetailIndex = index;
                    showCharacterDetails(characterId);
                }
            });

            // Actualiza el estado de los botones Anterior, Siguiente, y los de detalle
            updateButtonsState(page, response.info.next, response.info.prev);
            updateDetailNavButtons();
        }).fail((jqXHR, textStatus, errorThrown) => {
            console.error('Error:', textStatus, errorThrown);
            $('#data').html('<p>Error al cargar los datos.</p>');
        });
    }

   // Función para mostrar los detalles de un personaje
function showCharacterDetails(characterId: string): void {
    const characterDetailsUrl: string = `https://starwars-databank-server.vercel.app/api/v1/characters/${characterId}`;

    $.get(characterDetailsUrl, (character: Character) => {
        const detailsHtml: string = `<div class="character-details-content">
                                        <img src="${character.image}" alt="${character.name}" style="width:200px; height:auto;">
                                        <p><strong>Nombre:</strong> ${character.name}</p>
                                        <p><strong>Descripción:</strong> ${character.description || 'Descripción no disponible'}</p>
                                        <p><strong>ID:</strong> ${character._id}</p>
                                     </div>`;
        $('#character-details').html(detailsHtml).show();
        
        // Muestra los botones de navegación de detalles
        $('#details-prev, #details-next').show();

        // Actualiza el estado de los botones de navegación de detalles
        updateDetailNavButtons();
    }).fail((jqXHR, textStatus, errorThrown) => {
        console.error('Error:', textStatus, errorThrown);
        $('#character-details').html('<p>Error al cargar los detalles del personaje.</p>');
    });
}

    // Función para actualizar el estado de los botones Anterior y Siguiente
    function updateButtonsState(page: number, next: string | null, prev: string | null): void {
        $('#next').prop('disabled', !next);
        $('#prev').prop('disabled', page === 1 || !prev);
    }

    // Función para actualizar los botones de navegación de detalles
    function updateDetailNavButtons(): void {
        $('#details-prev').prop('disabled', currentDetailIndex <= 0);
        $('#details-next').prop('disabled', currentDetailIndex >= characterIds.length - 1);
    }

    // Evento de clic para el botón Siguiente
    $('#next').click(() => {
        currentPage++;
        loadCharacters(currentPage);
    });

    // Evento de clic para el botón Anterior
    $('#prev').click(() => {
        if (currentPage > 1) {
            currentPage--;
            loadCharacters(currentPage);
        }
    });

    // Eventos de clic para los botones de detalles Siguiente y Anterior
    $('#details-next').click(() => {
        if (currentDetailIndex < characterIds.length - 1) {
            currentDetailIndex++;
            const characterId: string = characterIds[currentDetailIndex];
            showCharacterDetails(characterId);
        }
    });

    $('#details-prev').click(() => {
        if (currentDetailIndex > 0) {
            currentDetailIndex--;
            const characterId: string = characterIds[currentDetailIndex];
            showCharacterDetails(characterId);
        }
    });

    // Carga inicial de personajes
    loadCharacters(currentPage);
});
