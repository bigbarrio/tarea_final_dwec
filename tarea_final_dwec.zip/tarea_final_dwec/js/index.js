"use strict";
$(document).ready(function () {
    var currentPage = 1; // Inicia en la página 1
    var limit = 10; // Número de personajes por página
    var characterIds = []; // Especifica explícitamente el tipo como string[]
    var currentDetailIndex = 0; // Índice del detalle del personaje actualmente visible
    // Función para cargar personajes según la página actual
    function loadCharacters(page) {
        var charactersUrl = "https://starwars-databank-server.vercel.app/api/v1/characters?page=".concat(page, "&limit=").concat(limit);
        $.get(charactersUrl, function (response) {
            var html = "<div>"; // Contenedor para las tarjetas de personajes
            characterIds = response.data.map(function (character) { return character._id; }); // Actualiza el arreglo de IDs
            response.data.forEach(function (character) {
                html += "<div class=\"character-card\" data-id=\"".concat(character._id, "\">\n                            <img src=\"").concat(character.image, "\" alt=\"").concat(character.name, "\" class=\"character-image\">\n                            <h2 class=\"character-name\">").concat(character.name, "</h2>\n                         </div>");
            });
            html += "</div>";
            $('#data').html(html);
            // Asigna el evento de clic a cada tarjeta de personaje
            $('.character-card').click(function () {
                var characterId = $(this).data('id');
                var index = characterIds.indexOf(characterId);
                if (index !== -1) {
                    currentDetailIndex = index;
                    showCharacterDetails(characterId);
                }
            });
            // Actualiza el estado de los botones Anterior, Siguiente, y los de detalle
            updateButtonsState(page, response.info.next, response.info.prev);
            updateDetailNavButtons();
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error:', textStatus, errorThrown);
            $('#data').html('<p>Error al cargar los datos.</p>');
        });
    }
    // Función para mostrar los detalles de un personaje
    function showCharacterDetails(characterId) {
        var characterDetailsUrl = "https://starwars-databank-server.vercel.app/api/v1/characters/".concat(characterId);
        $.get(characterDetailsUrl, function (character) {
            var detailsHtml = "<div class=\"character-details-content\">\n                                        <img src=\"".concat(character.image, "\" alt=\"").concat(character.name, "\" style=\"width:200px; height:auto;\">\n                                        <p><strong>Nombre:</strong> ").concat(character.name, "</p>\n                                        <p><strong>Descripci\u00F3n:</strong> ").concat(character.description || 'Descripción no disponible', "</p>\n                                        <p><strong>ID:</strong> ").concat(character._id, "</p>\n                                     </div>");
            $('#character-details').html(detailsHtml).show();
            // Muestra los botones de navegación de detalles
            $('#details-prev, #details-next').show();
            // Actualiza el estado de los botones de navegación de detalles
            updateDetailNavButtons();
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error:', textStatus, errorThrown);
            $('#character-details').html('<p>Error al cargar los detalles del personaje.</p>');
        });
    }
    // Función para actualizar el estado de los botones Anterior y Siguiente
    function updateButtonsState(page, next, prev) {
        $('#next').prop('disabled', !next);
        $('#prev').prop('disabled', page === 1 || !prev);
    }
    // Función para actualizar los botones de navegación de detalles
    function updateDetailNavButtons() {
        $('#details-prev').prop('disabled', currentDetailIndex <= 0);
        $('#details-next').prop('disabled', currentDetailIndex >= characterIds.length - 1);
    }
    // Evento de clic para el botón Siguiente
    $('#next').click(function () {
        currentPage++;
        loadCharacters(currentPage);
    });
    // Evento de clic para el botón Anterior
    $('#prev').click(function () {
        if (currentPage > 1) {
            currentPage--;
            loadCharacters(currentPage);
        }
    });
    // Eventos de clic para los botones de detalles Siguiente y Anterior
    $('#details-next').click(function () {
        if (currentDetailIndex < characterIds.length - 1) {
            currentDetailIndex++;
            var characterId = characterIds[currentDetailIndex];
            showCharacterDetails(characterId);
        }
    });
    $('#details-prev').click(function () {
        if (currentDetailIndex > 0) {
            currentDetailIndex--;
            var characterId = characterIds[currentDetailIndex];
            showCharacterDetails(characterId);
        }
    });
    // Carga inicial de personajes
    loadCharacters(currentPage);
});
//# sourceMappingURL=index.js.map